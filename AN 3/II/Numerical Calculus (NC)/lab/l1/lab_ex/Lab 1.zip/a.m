a = [1 2 3]
b = [4; 5; 6] %column vector
c = a * b
d = b'
e = a.*d
f = a.^2
g = a.^d
v = 1:6
w = 2 : 3 : 10 %the starting point:step:the ...nal point
y = 10 : -1 : 0
exp(a)
exp(1) %number e
sqrt(a)
m = max(a)
[m, k] = max(a)
h = [-2 -9 8]
k = abs(h)
mean(a)
pkg load statistics
geomean(a)
sum(a)
prod(a) 
