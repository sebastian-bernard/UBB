p = [2 -5 0 8];
polyval(p, 2)
p = [1 -5 -17 21];
roots(p)